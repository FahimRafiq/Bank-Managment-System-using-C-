﻿using System;
using System.Security;
using System.IO;
using System.Net.Mail;
using System.Net;
using System.Text;

namespace BankManagementSystem
{
    class LoginInterface
    {
        //Login Variables
        String[] loginWindowFields = { "Username: ","Password: " };
        int[,] loginFieldPos = new int[2, 2];
        String[] loginUserInputs = new string[2];

        //Login Screen creation
        public void loginScreen(int noLines, int formWidth, int startRow, int startCol)
        {
            do
            {
                Console.Clear(); //Clear the screen 
                UserInterface.origRow = Console.CursorTop;
                UserInterface.origCol = Console.CursorLeft;

                // Print the border
                for (int line=0; line< noLines; line++)
                {
                    if(line ==0 | line == 2 | line == (noLines - 1))
                    {
                        for (int col=0; col< formWidth; col++)
                        {
                            UserInterface.WriteAt("=", startCol + col, startRow + line);
                        }
                    }
                    else
                    {
                        UserInterface.WriteAt("|", startCol, startRow + line);
                        UserInterface.WriteAt("|", startCol + formWidth - 1, startRow + line);
                    }
                }

                // Print Titles 
                UserInterface.WriteAt("Welcome to the Bank", startCol +15,startRow +1);
                UserInterface.WriteAt("Login To Start", startCol + 17, startRow+4);

                //Field Names display
                int item = 0;
                foreach( string fieldName in loginWindowFields)
                {
                    UserInterface.WriteAt(fieldName, startCol + 6, startRow + 6 + item);
                    loginFieldPos[item, 1] = Console.CursorTop;
                    loginFieldPos[item, 0] = Console.CursorLeft;
                    ++item;
                }
          
                //Get user credentials
                for (int field = 0; field < item; field++)
                {
                    if(field == 0)
                    {
                        Console.SetCursorPosition(loginFieldPos[field, 0], loginFieldPos[field, 1]);
                        loginUserInputs[field] = Console.ReadLine();
                    }
                    else
                    {
                        Console.SetCursorPosition(loginFieldPos[field, 0], loginFieldPos[field, 1]);
                        loginUserInputs[field] = maskInputString();
                    }
                    
                }

                //Validate user credentials
                bool credentialValid = validateUserCredential();
                if(credentialValid == true)
                {
                    UserInterface.WriteAt("Valid Credentials, Press Enter to continue", startCol, noLines + 2);
                    Console.ReadKey();
                    break;

                }
                else
                {
                    UserInterface.WriteAt("Invalid Credentials, Press enter to continue", startCol, noLines + 2);
                    Console.ReadKey();
                }

            } while (true);

        }

        //Hide password using Asterisks
        private static string maskInputString()
        {
            SecureString pass = new SecureString();
            ConsoleKeyInfo keyInfo;
            do
            {
                keyInfo = Console.ReadKey(true);
                if (!char.IsControl(keyInfo.KeyChar))
                {
                    pass.AppendChar(keyInfo.KeyChar);
                    Console.Write("*");
                } else if (keyInfo.Key == ConsoleKey.Backspace && pass.Length > 0)
                {
                    pass.RemoveAt(pass.Length - 1);
                    Console.Write("\b \b");
                }
            } while (keyInfo.Key != ConsoleKey.Enter);

            String password = new System.Net.NetworkCredential(string.Empty, pass).Password;
            return password; 
        }

        // Validat User credential with login.txt, returns true/false
        public bool validateUserCredential()
        {
            //string[] lines = System.IO.File.ReadAllLines(@"C:\Users\atomi\source\repos\BankManagementSystem\login.txt");
            string[] lines = System.IO.File.ReadAllLines("../../../../login.txt");
            bool credential = false;
            foreach (string line in lines)
            {
                String[] name = line.Split('|');
                if (loginUserInputs[0].CompareTo(name[0]) == 0 && loginUserInputs[1].CompareTo(name[1]) == 0)
                {
                    credential = true;
                    break; 
                }
            }

            return credential;
        }




    }
//Class to write characters to the console screen
    class UserInterface
    {
        public static int origRow;
        public static int origCol;
 

        public static void WriteAt(string s, int x, int y)
        {
            try
            {
                Console.SetCursorPosition(origCol + x, origRow + y);
                Console.Write(s);
            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.Clear();
                Console.WriteLine(e.Message);
            }
        }
    }
    //Main Menu Class
    class MainMenuInterface
    {
        //Main Menu Variables
        String[] mainMenuFields = { "1. Create a new account", "2. Search for an account", "3. Deposit", "4. Withdraw", "5. A/C statement", "6. Delete account", "7. Exit" };
        int[] mainMenuChoicePos = new int[2];
        int mainMenuChoice;

        public int menuScreen(int noLines, int formWidth, int startRow, int startCol)
        {
            do
            {
                Console.Clear();
                UserInterface.origRow = Console.CursorTop;
                UserInterface.origCol = Console.CursorLeft;

                //Print the border
                for (int line = 0; line < noLines; line++)
                {
                    if (line == 0 | line == 2 | line == (noLines - 1) | line == (noLines - 3))
                    {
                        for (int col = 0; col < formWidth; col++)
                        {
                            UserInterface.WriteAt("=", startCol + col, startRow + line);
                        }
                    }
                    else
                    {
                        UserInterface.WriteAt("|", startCol, startRow + line);
                        UserInterface.WriteAt("|", startCol + formWidth - 1, startRow + line);
                    }
                }

                // Print Titles 
                UserInterface.WriteAt("What would you like to do today?", startCol + 10, startRow + 1);

                //Print choice option
                UserInterface.WriteAt("Enter your choice: ", startCol + 10, startRow + 11);
                mainMenuChoicePos[1] = Console.CursorTop;
                mainMenuChoicePos[0] = Console.CursorLeft;

                //Field Names display
                int item = 0;
                foreach (string fieldName in mainMenuFields)
                {
                    UserInterface.WriteAt(fieldName, startCol + 6, startRow + 3 + item);
                    ++item;
                }

                //Get User Choice
                while(true)
                {
                    try { 
                        Console.SetCursorPosition(mainMenuChoicePos[0], mainMenuChoicePos[1]);
                        mainMenuChoice = Convert.ToInt32(Console.ReadLine());                 
                        if (mainMenuChoice >= 1 && mainMenuChoice < 8)
                        {
                            break;
                        }
                        else
                        {
                            UserInterface.WriteAt("        ", mainMenuChoicePos[0], mainMenuChoicePos[1]);
                            UserInterface.WriteAt("Wrong choice, Enter again: ", 3, 13);
                            
                        }
                    }catch(Exception e)
                    {
                        UserInterface.WriteAt("        ", mainMenuChoicePos[0], mainMenuChoicePos[1]);
                        UserInterface.WriteAt("Enter number! ", 3, 13);
                    }
                }

                break;

            } while (true);


            return mainMenuChoice;
        }
    }
// Create Account Class
    class CreateAccountInterface
    {
        //Create account variables
        string[] createAccountFields = {"First Name: ", "Last Name: ", "Address: ", "Phone: ", "Email: " };
        int[,] createAccountFieldPos = new int[5,5];
        string[] createAccountInputs = new string[5];

        //Create Create Account form

        public void createAccount(int noLines, int formWidth, int startRow, int startCol)
        {
            do
            {
                Console.Clear();
                UserInterface.origRow = Console.CursorTop;
                UserInterface.origCol = Console.CursorLeft;

                //Print the border
                for (int line = 0; line < noLines; line++)
                {
                    if (line == 0 | line == 2 | line == (noLines - 1))
                    {
                        for (int col = 0; col < formWidth; col++)
                        {
                            UserInterface.WriteAt("=", startCol + col, startRow + line);
                        }
                    }
                    else
                    {
                        UserInterface.WriteAt("|", startCol, startRow + line);
                        UserInterface.WriteAt("|", startCol + formWidth - 1, startRow + line);
                    }
                }

                //Print Titles
                UserInterface.WriteAt("Create Account", startCol + 18, startRow + 1);
                UserInterface.WriteAt("Enter details", startCol + 18, startRow + 3);

                //Field Names display
                int item = 0;
                foreach(string fieldName in createAccountFields)
                {
                    UserInterface.WriteAt(fieldName, startCol + 6, startRow + 5 + item);
                    createAccountFieldPos[item, 1] = Console.CursorTop;
                    createAccountFieldPos[item, 0] = Console.CursorLeft;
                    ++item;
                }

                //Get user data
                for (int field = 0; field < item; field++)
                {
                    if (field == 3)
                    {
                        Console.SetCursorPosition(createAccountFieldPos[field, 0], createAccountFieldPos[field, 1]);
                        //check for valid phone number
                        string temp = Console.ReadLine();
                        while(temp.Length != 10 || !(int.TryParse(temp, out int value)))
                        {
                            UserInterface.WriteAt("Invalivd phone number. Enter again: ", startCol+1, startRow+ 11 );
                            UserInterface.WriteAt("                 ",createAccountFieldPos[field,0], createAccountFieldPos[field, 1]);
                            Console.SetCursorPosition(createAccountFieldPos[field, 0], createAccountFieldPos[field, 1]);
                            temp = Console.ReadLine();
                        }
                        createAccountInputs[field] = temp;
                        UserInterface.WriteAt("                                   ", startCol + 1, startRow + 11);
                    }

                    else if(field == 4)
                    {
                        Console.SetCursorPosition(createAccountFieldPos[field, 0], createAccountFieldPos[field, 1]);
                        string temp = Console.ReadLine();
                        //Check for valid email
                        while (!temp.Contains("@gmail.com") && !temp.Contains("@outlook.com"))
                        {
                            UserInterface.WriteAt("Invalivd Email. Enter again: ", startCol + 1, startRow + 11);
                            UserInterface.WriteAt("                 ", createAccountFieldPos[field, 0], createAccountFieldPos[field, 1]);
                            Console.SetCursorPosition(createAccountFieldPos[field, 0], createAccountFieldPos[field, 1]);
                            temp = Console.ReadLine();
                        }
                        createAccountInputs[field] = temp;
                        UserInterface.WriteAt("                                   ", startCol + 1, startRow + 11);

                    }
                    else
                    {
                        Console.SetCursorPosition(createAccountFieldPos[field, 0], createAccountFieldPos[field, 1]);
                        createAccountInputs[field] = Console.ReadLine();
                    }

                }
                // Confirm with user
                UserInterface.WriteAt("Proceed: y/n? :", startCol+1, startRow+12);
                int ProceedCursorX = Console.CursorTop;
                int ProceedCursorY = Console.CursorLeft;
                String answer = Console.ReadLine();

                //Check Answer
                if (answer.CompareTo("y") == 0)
                {
                    
                    string uniqueAccountNumber = checkAccountNumbers(createAccountInputs);
                    sendMail(createAccountInputs);
                    string accountNumberText = "You account number is: " + uniqueAccountNumber;
                    UserInterface.WriteAt(accountNumberText, startCol + 1, startRow + 16);
                    UserInterface.WriteAt("Account information has been emailed", startCol + 1, startRow + 17);
                    Console.ReadKey();
                    break;
                }


        
            }while (true);


        }

        public static string checkAccountNumbers(string[] accountInfo)
        {
            //Generate random number
            String startWith = "10"; //begining with 10
            Random generator = new Random();
            String r = generator.Next(0, 999999).ToString("D6");  //6 random digits
            String aAccounNumber = startWith + r;

            //Open the account and write account details to it
            try
            {
                
                string path = "../../../../" + aAccounNumber + ".txt";
                StreamWriter sw = null;
                if(!File.Exists(path)) 
                {
                    
                   
                    path = "../../../../" + aAccounNumber + ".txt";
                    sw = File.CreateText(path);
                    string accountInfobody = String.Join(" \n", accountInfo);
                    foreach (string sentence in accountInfo)
                    {
                        sw.WriteLine(sentence);
                    }
                    sw.WriteLine(aAccounNumber);
                    sw.WriteLine("0");
                    

                }
                sw.Close();
            }
            catch(Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);

            }
            return aAccounNumber;

        }
        //Email Method
        public static void sendMail(string[] mailBody)
        {
            string body = String.Join(" \n",mailBody);

            var smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new NetworkCredential("dotnetassignment01@gmail.com", "assignment01"),
                EnableSsl = true,
            };

            smtpClient.Send("dotnetassignment01@gmail.com", "dotnetassignment01@gmail.com", "Account Created! Welcome to the bank.", body);
        }


    }
//Search Account Class
    class searchAccountInterface
    {
        //Create searchAccount Variables
        string[] searchAccountFields = {"Account Number: "};
        int[] searchAccountFieldPos = new int[2];
        string[] searchAccountInputs = new string[1];

        //Create searchAccount form
        public void searchAccount(int noLines, int formWidth, int startRow, int startCol)
        {
            do
            {
                Console.Clear();
                UserInterface.origRow = Console.CursorTop;
                UserInterface.origCol = Console.CursorLeft;

                String answer = "";
                int searchAccountCursorX;
                int searchAccountCursorY;
                bool searchAnother = false;
                bool validAccount = true;

                //Print the border
                for (int line = 0; line < noLines; line++)
                {
                    if (line == 0 | line == 2 | line == (noLines - 1))
                    {
                        for (int col = 0; col < formWidth; col++)
                        {
                            UserInterface.WriteAt("=", startCol + col, startRow + line);
                        }
                    }
                    else
                    {
                        UserInterface.WriteAt("|", startCol, startRow + line);
                        UserInterface.WriteAt("|", startCol + formWidth - 1, startRow + line);
                    }
                }

                //Print Titles
                UserInterface.WriteAt("Search an Account", startCol + 10, startRow + 1);
                UserInterface.WriteAt("Enter details", startCol + 10, startRow + 3);

                //Field Names display
                int item = 0;
                foreach (string fieldName in searchAccountFields)
                {
                    UserInterface.WriteAt(fieldName, startCol + 6, startRow + 5 + item);
                    searchAccountFieldPos[1] = Console.CursorTop;
                    searchAccountFieldPos[0] = Console.CursorLeft;
                    ++item;
                }

                //Get user account number
                for (int field = 0; field < item; field++)
                {
                    Console.SetCursorPosition(searchAccountFieldPos[0], searchAccountFieldPos[1]);
                    string temp = Console.ReadLine();
                    //string path = "../../../../" + temp + ".txt";
                    //check if input is Integer and within 10 characters length
                    while (temp.Length > 10 || temp.Length < 1 || !(int.TryParse(temp, out int value)))
                    {
                        validAccount = false; 
                        UserInterface.WriteAt("Invalid account number", startCol + 6, startRow + 8);
                        UserInterface.WriteAt("Check another account (y/n)?", startCol + 6, startRow + 9);
  
                        answer = Console.ReadLine();
                        //Try again
                        if (answer.CompareTo("y") == 0)
                        {
                            UserInterface.WriteAt("                  ", searchAccountFieldPos[0], searchAccountFieldPos[1]);
                            UserInterface.WriteAt("                       ", startCol + 6, startRow + 8);
                            UserInterface.WriteAt("                             ", startCol + 6, startRow + 9);
                            Console.SetCursorPosition(searchAccountFieldPos[0], searchAccountFieldPos[1]);
                            temp = Console.ReadLine();
                            validAccount = true;
                        }
                        else {
                            searchAnother = false;
                            break;
                        };

                    }
                    //Take valid input and clear the previous line
                    if (validAccount)
                    {
                        searchAccountInputs[field] = temp;
                        UserInterface.WriteAt("                                   ", startCol + 6, startRow + 8);
                    }

                }
                //Search the account name by finding the account file
                try
                {


                    if (!validAccount)
                    {
                        break;
                    }
                    string path = "../../../../"+searchAccountInputs[0]+".txt";

                    bool continueAnotherAccount = false;
                    if (File.Exists(path))
                    {
                        UserInterface.WriteAt("Account found", startCol +6, startRow + 8);
                        continueAnotherAccount = accoutDetails(14,40,9,5, searchAccountInputs[0]);
                        
                    }
                    else
                    {
                        UserInterface.WriteAt("Account not found", startCol + 6, startRow + 8);
                        UserInterface.WriteAt("Check another account (y/n)?", startCol + 6, startRow + 9);
                        searchAccountCursorX = Console.CursorTop;
                        searchAccountCursorY = Console.CursorLeft;
                       
                        answer = Console.ReadLine();
                    }

                    if (answer.CompareTo("y")==0 || continueAnotherAccount == true)
                    {
                        UserInterface.WriteAt("                       ", startCol + 6, startRow + 8);
                        UserInterface.WriteAt("                             ", startCol + 6, startRow + 9);
                    }
                    else { break; };

                }catch(Exception e)
                {
                    Console.WriteLine(e);
                }

            } while (true);
        }
        //print account details method
        public bool accoutDetails(int noLines, int formWidth, int startRow, int startCol, string accountNo)
        {
            do
            {
                //Print border
                for (int line = 0; line < noLines; line++)
                {
                    if (line == 0 | line == 2 | line == (noLines - 1))
                    {
                        for (int col = 0; col < formWidth; col++)
                        {
                            UserInterface.WriteAt("=", startCol + col, startRow + line);
                        }
                    }
                    else
                    {
                        UserInterface.WriteAt("|", startCol, startRow + line);
                        UserInterface.WriteAt("|", startCol + formWidth - 1, startRow + line);
                    }
                }

                //Print Titles
                UserInterface.WriteAt("Account Details", startCol + 10, startRow + 1);
                //print Account number:
                string accountNumber = "Account No: " + accountNo;
                UserInterface.WriteAt(accountNumber, startCol + 2, startRow + 4);
                string path = "../../../../" + accountNo + ".txt";
                string sentence;
                //Get information from account file

                string[] fieldLabels = { "First Name: ", "Last Name: ", "Address: ", "Phone: ", "Email: ", "Account No: ","Balance: " };
                string[] fieldLines = new string[7];

                //Account balance variable
                string accountBalanceFromText = "";
                try
                {
                    StreamReader sr = new StreamReader(path);
                    string line = sr.ReadLine();
                    int itemNo = 0;
                    while (line != null)
                    {
                        if(itemNo == 6)
                        {
                            accountBalanceFromText = line;
                            fieldLines[itemNo] = fieldLabels[itemNo] + line;
                            break;
                        }
                        fieldLines[itemNo] = fieldLabels[itemNo] + line;
                        ++itemNo;
                        line = sr.ReadLine();
                    }

                    sr.Close();

                }catch(Exception e) 
                {
                    Console.WriteLine(e);
                }

                //Print Account Balance           
                string accountBalance = fieldLines[6];
                UserInterface.WriteAt(accountBalance, startCol + 2, startRow + 5);

                //Print info
                for (int field = 0; field< fieldLines.Length-2; ++field)
                {
                    UserInterface.WriteAt(fieldLines[field],startCol+2, startRow+6+ field );
                }

                //Check another account
                UserInterface.WriteAt("check another account (y/n)? : ", startCol, startRow + 14);
                String answer = Console.ReadLine();
                if (answer.CompareTo("n") == 0)
                {
                    break;
                }
                else
                {
                    return true;
                   
                }

            } while (true);

            return false;
        }

    }
    //Deposit Class
    class DepositInterface
    {
        //Create deposit variables
        string[] depositFields = { "Account Number: ", "Amount: $" };
        int[,] depositFieldPos = new int[2, 2];
        string[] depositInputs = new string[2];
        string depositAmount = "";
        //Create deposit form

        public void deposit(int noLines, int formWidth, int startRow, int startCol)
        {
            do
            {
                Console.Clear();
                String answer = "";
                bool searchAnother = true;
                bool validAccount = true;

                //print the borders
                for (int line = 0; line < noLines; line++)
                {
                    if (line == 0 | line == 2 | line == (noLines - 1))
                    {
                        for (int col = 0; col < formWidth; col++)
                        {
                            UserInterface.WriteAt("=", startCol + col, startRow + line);
                        }
                    }
                    else
                    {
                        UserInterface.WriteAt("|", startCol, startRow + line);
                        UserInterface.WriteAt("|", startCol + formWidth - 1, startRow + line);
                    }
                }

                //Print titles
                UserInterface.WriteAt("Deposit", startCol + 21, startRow + 1);
                UserInterface.WriteAt("Enter details", startCol + 18, startRow + 3);

                //Field Name Display
                int item = 0;
                foreach (string fieldName in depositFields)
                {
                    UserInterface.WriteAt(fieldName, startCol + 6, startRow + 5 + item);
                    depositFieldPos[item,1] = Console.CursorTop;
                    depositFieldPos[item,0] = Console.CursorLeft;
                    ++item;
                }

                //Get user data
                //Get user account number
                for (int field = 0; field < 1; field++)
                {
                    Console.SetCursorPosition(depositFieldPos[field,0], depositFieldPos[field,1]);
                   
                    string temp = Console.ReadLine();
                    string path = "../../../../" + temp + ".txt";
                    //!File.Exists(path)
                    //check if input is Integer and within 10 characters length
                    while (temp.Length > 10 || temp.Length < 1 || !(int.TryParse(temp, out int value)) || !File.Exists(path) )
                    {
                        validAccount = false;
                        UserInterface.WriteAt("Invalid account number", startCol + 6, startRow + 10);
                        UserInterface.WriteAt("Check another account (y/n)?", startCol + 6, startRow + 11);

                        answer = Console.ReadLine();

                        if (answer.CompareTo("y") == 0)
                        {
                            UserInterface.WriteAt("                ", depositFieldPos[0,0], depositFieldPos[0,1]);
                            UserInterface.WriteAt("                ", depositFieldPos[1, 0], depositFieldPos[1, 1]);
                            UserInterface.WriteAt("                       ", startCol + 6, startRow + 10);
                            UserInterface.WriteAt("                             ", startCol + 6, startRow + 11);
                            Console.SetCursorPosition(depositFieldPos[field,0], depositFieldPos[field,1]);
                            temp = Console.ReadLine();
                            validAccount = true;
                        }
                        else
                        {
                            searchAnother = false;
                            break;
                        };

                    }
                    if (validAccount && searchAnother)
                    {
                        depositInputs[0] = temp;
                        UserInterface.WriteAt("                                   ", startCol + 6, startRow + 8);
                        UserInterface.WriteAt("Valid account. Enter amount...", startCol + 6, startRow + 8);
                        Console.SetCursorPosition(depositFieldPos[1, 0], depositFieldPos[1, 1]);
                        depositAmount = Console.ReadLine();
                        depositInputs[1] = depositAmount;
                        UserInterface.WriteAt("Deposit Sucessfull!", startCol + 15, startRow + 10);
                        Console.ReadKey();
                        break;


                    }
                    else break;

                }

                //Upon valid account input add transaction to the account file
                if (validAccount)
                {
                    //Get todays date
                    DateTime thisDay = DateTime.Today;
                    string date = thisDay.ToString("d");

                    //Open Account text file to add deposit and update Balance
                    try
                    {
                        string path = "../../../../" + depositInputs[0] + ".txt";
                        string[] lines = File.ReadAllLines(path);

                        String currentBalance = "";
                        int startOfTransaction = 0;
                        foreach(string line in lines)
                        {
                            
                            if(startOfTransaction == 6)
                            {
                                currentBalance = line;
                            }
                            ++startOfTransaction;
                        }
                    
                        double updatedBalance = Convert.ToDouble(currentBalance) + Convert.ToDouble(depositInputs[1]);
                        string updatedBalanceString = Convert.ToString(updatedBalance);

                        StreamWriter sw = File.AppendText(path);
                        
                        string toAppend = date + "|" + "Deposit" + "|" + depositInputs[1]+"|"+updatedBalanceString;
                        sw.WriteLine(toAppend);
                        sw.Close();

                        string[] sentences = File.ReadAllLines(path);
                        sentences[6] = updatedBalanceString;
                      
                        File.WriteAllLines(path,sentences);
                   

                    }
                    catch(Exception e) { Console.WriteLine("Exception: "+e); }

                    break;
                }
                if(!searchAnother) break;


            } while (true);
        }

    }
//Withdraw Class
    class WithdrawInterface
    {
        //Create withrdraw variables
        //Create deposit variables
        string[] withdrawFields = { "Account Number: ", "Amount: $" };
        int[,] withdrawFieldPos = new int[2, 2];
        string[] withdrawInputs = new string[2];
        string withdrawAmount = "";

        //Create withdraw form

        public void withdraw(int noLines, int formWidth, int startRow, int startCol)
        {
            do
            {
                Console.Clear();
                String answer = "";
                bool searchAnother = true;
                bool validAccount = true;
                bool allowWithdraw = true;

                //print the borders
                for (int line = 0; line < noLines; line++)
                {
                    if (line == 0 | line == 2 | line == (noLines - 1))
                    {
                        for (int col = 0; col < formWidth; col++)
                        {
                            UserInterface.WriteAt("=", startCol + col, startRow + line);
                        }
                    }
                    else
                    {
                        UserInterface.WriteAt("|", startCol, startRow + line);
                        UserInterface.WriteAt("|", startCol + formWidth - 1, startRow + line);
                    }
                }

                //Print titles
                UserInterface.WriteAt("Withdraw", startCol + 21, startRow + 1);
                UserInterface.WriteAt("Enter details", startCol + 18, startRow + 3);

                //Field Name Display
                int item = 0;
                foreach (string fieldName in withdrawFields)
                {
                    UserInterface.WriteAt(fieldName, startCol + 6, startRow + 5 + item);
                    withdrawFieldPos[item, 1] = Console.CursorTop;
                    withdrawFieldPos[item, 0] = Console.CursorLeft;
                    ++item;
                }

                //Get user data
                //Get user account number
                for (int field = 0; field < 1; field++)
                {
                    Console.SetCursorPosition(withdrawFieldPos[field, 0], withdrawFieldPos[field, 1]);

                    string temp = Console.ReadLine();
                    string path = "../../../../" + temp + ".txt";
                    //!File.Exists(path)
                    //check if input is Integer and within 10 characters length
                    while (temp.Length > 10 || temp.Length < 1 || !(int.TryParse(temp, out int value)) || !File.Exists(path))
                    {
                        validAccount = false;
                        UserInterface.WriteAt("Invalid account number", startCol + 6, startRow + 10);
                        UserInterface.WriteAt("Check another account (y/n)?", startCol + 6, startRow + 11);

                        answer = Console.ReadLine();

                        if (answer.CompareTo("y") == 0)
                        {
                            UserInterface.WriteAt("                ", withdrawFieldPos[0, 0], withdrawFieldPos[0, 1]);
                            UserInterface.WriteAt("                ", withdrawFieldPos[1, 0], withdrawFieldPos[1, 1]);
                            UserInterface.WriteAt("                       ", startCol + 6, startRow + 10);
                            UserInterface.WriteAt("                                                 ", startCol + 6, startRow + 11);
                            Console.SetCursorPosition(withdrawFieldPos[field, 0], withdrawFieldPos[field, 1]);
                            temp = Console.ReadLine();
                            validAccount = true;
                        }
                        else
                        {
                            searchAnother = false;
                            break;
                        };

                    }
                    if (validAccount && searchAnother)
                    {
                        withdrawInputs[0] = temp;
                        UserInterface.WriteAt("                                   ", startCol + 6, startRow + 8);
                        UserInterface.WriteAt("Valid account. Enter amount...", startCol + 6, startRow + 8);
                        Console.SetCursorPosition(withdrawFieldPos[1, 0], withdrawFieldPos[1, 1]);
                        withdrawAmount = Console.ReadLine();
                        withdrawInputs[1] = withdrawAmount;

                        
                        allowWithdraw = checkWithdrawlAmount();
                        if (allowWithdraw)
                        {
                            UserInterface.WriteAt("Withdraw Sucessfull!", startCol + 6, startRow + 9);
                            Console.ReadKey();
                            break;
                        }
                        else
                        {
                            UserInterface.WriteAt("Withdraw amount exceeds current balance!", startCol + 6, startRow + 10);
                            UserInterface.WriteAt("Transaction failed! Press enter to try again", startCol + 6, startRow + 11);
                            Console.ReadKey();
                            validAccount = false;
                        }
                        


                    }

                }

                //If account number is valid then let amount of to be withdrawed and account file to be updated
                if (validAccount)
                {
                    //Get todays date
                    DateTime thisDay = DateTime.Today;
                    string date = thisDay.ToString("d");

                    //Open Account text file to add withdraw and update Balance
                    try
                    {
                        string path = "../../../../" + withdrawInputs[0] + ".txt";
                        string[] lines = File.ReadAllLines(path);

                        String currentBalance = "";
                        int startOfTransaction = 0;
                        foreach (string line in lines)
                        {
                            
                            if (startOfTransaction == 6)
                            {
                                currentBalance = line;
                            }
                            ++startOfTransaction;
                        }
                       
                        double updatedBalance = Convert.ToDouble(currentBalance) - Convert.ToDouble(withdrawInputs[1]);
                        string updatedBalanceString = Convert.ToString(updatedBalance);

                        StreamWriter sw = File.AppendText(path);

                        string toAppend = date + "|" + "Withdraw" + "|" + withdrawInputs[1] + "|" + updatedBalanceString;
                        sw.WriteLine(toAppend);
                        sw.Close();

                        string[] sentences = File.ReadAllLines(path);
                        sentences[6] = updatedBalanceString;
                        
                        File.WriteAllLines(path, sentences);
                     

                    }
                    catch (Exception e) { Console.WriteLine("Exception: " + e); }

                    break;
                }

                if (!searchAnother) break;

            } while (true);
        }

        //method to check if withdrawl amount is less then current balance
        public bool checkWithdrawlAmount()
        {
            try
            {
                string path = "../../../../" + withdrawInputs[0] + ".txt";
                string[] lines = File.ReadAllLines(path);

                String currentBalance = "";
                int startOfTransaction = 0;
                foreach (string line in lines)
                {
                    
                    if (startOfTransaction == 6)
                    {
                        currentBalance = line;
                    }
                    else if (startOfTransaction > 6)
                    {
                        //Code Remaining
                    }
                    ++startOfTransaction;
                }
                double checkBalance = Convert.ToDouble(currentBalance) - Convert.ToDouble(withdrawInputs[1]);
                if (checkBalance < 0)
                {
                    return false;
                }
                else return true;

            }
            catch (Exception e)
            {
                Console.WriteLine("Exception : "+e);
            }

            return true;
        }
    }
//Account Statement Class
    class AccountStatement
    {
        //Create AccountStatement Variables
        string[] accountStatementFields = { "Account Number: " };
        int[] accountStatementFieldPos = new int[2];
        string[] accountStatementInputs = new string[1];

        public void accountStatement(int noLines, int formWidth, int startRow, int startCol)
        {
            do
            {
                Console.Clear();
                UserInterface.origRow = Console.CursorTop;
                UserInterface.origCol = Console.CursorLeft;

                String answer = "";
                int accountStatementCursorX;
                int accountStatementCursorY;
                bool searchAnother = false;
                bool validAccount = true;

                //Print the border
                for (int line = 0; line < noLines; line++)
                {
                    if (line == 0 | line == 2 | line == (noLines - 1))
                    {
                        for (int col = 0; col < formWidth; col++)
                        {
                            UserInterface.WriteAt("=", startCol + col, startRow + line);
                        }
                    }
                    else
                    {
                        UserInterface.WriteAt("|", startCol, startRow + line);
                        UserInterface.WriteAt("|", startCol + formWidth - 1, startRow + line);
                    }
                }


                //Print Titles
                UserInterface.WriteAt("Statement", startCol + 20, startRow + 1);
                UserInterface.WriteAt("Enter Account details", startCol + 15, startRow + 3);

                //Field Names display
                int item = 0;
                foreach (string fieldName in accountStatementFields)
                {
                    UserInterface.WriteAt(fieldName, startCol + 6, startRow + 5 + item);
                    accountStatementFieldPos[1] = Console.CursorTop;
                    accountStatementFieldPos[0] = Console.CursorLeft;
                    ++item;
                }

                //Get user account number
                for (int field = 0; field < item; field++)
                {
                    Console.SetCursorPosition(accountStatementFieldPos[0], accountStatementFieldPos[1]);
                    string temp = Console.ReadLine();
                    string path = "../../../../" + temp + ".txt";
                    //check if input is Integer and within 10 characters length
                    while (temp.Length > 10 || temp.Length < 1 || !(int.TryParse(temp, out int value)) || !File.Exists(path))
                    {
                        validAccount = false;
                        UserInterface.WriteAt("Invalid account number", startCol + 6, startRow + 8);
                        UserInterface.WriteAt("Check another account (y/n)?", startCol + 6, startRow + 9);

                        answer = Console.ReadLine();

                        if (answer.CompareTo("y") == 0)
                        {
                            UserInterface.WriteAt("                  ", accountStatementFieldPos[0], accountStatementFieldPos[1]);
                            UserInterface.WriteAt("                       ", startCol + 6, startRow + 8);
                            UserInterface.WriteAt("                             ", startCol + 6, startRow + 9);
                            Console.SetCursorPosition(accountStatementFieldPos[0], accountStatementFieldPos[1]);
                            temp = Console.ReadLine();
                            validAccount = true;
                        }
                        else
                        {
                            searchAnother = false;
                            break;
                        };

                    }
                    if (validAccount)
                    {
                        accountStatementInputs[field] = temp;
                        UserInterface.WriteAt("                                   ", startCol + 6, startRow + 8);
                    }

                }
                
                try
                {
                    string searchAnotherAccount = "";
                    if (!validAccount)
                    {
                        break;
                    }
                    string path = "../../../../" + accountStatementInputs[0] + ".txt";

                    bool continueAnotherAccount = false;
                    if (File.Exists(path))
                    {
                        UserInterface.WriteAt("Account found", startCol + 13, startRow + 8);
                        accoutDetails(19, 40, 9, 5, accountStatementInputs[0]);

                    }
                    else
                    {
                        UserInterface.WriteAt("Account not found", startCol + 6, startRow + 8);
                        UserInterface.WriteAt("Check another account (y/n)?", startCol + 6, startRow + 9);
                        accountStatementCursorX = Console.CursorTop;
                        accountStatementCursorY = Console.CursorLeft;

                        searchAnotherAccount = Console.ReadLine();
                    }

                    if (searchAnotherAccount.CompareTo("y") == 0)
                    {
                        UserInterface.WriteAt("                       ", startCol + 6, startRow + 8);
                        UserInterface.WriteAt("                             ", startCol + 6, startRow + 9);
                    }
                    else { break; };

                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }

            } while (true);
        }
        //Print acount details method
        public void accoutDetails(int noLines, int formWidth, int startRow, int startCol, string accountNo)
        {
            do
            {
                //Print border
                for (int line = 0; line < noLines; line++)
                {
                    if (line == 0 | line == 2 | line == (noLines - 1))
                    {
                        for (int col = 0; col < formWidth; col++)
                        {
                            UserInterface.WriteAt("=", startCol + col, startRow + line);
                        }
                    }
                    else
                    {
                        UserInterface.WriteAt("|", startCol, startRow + line);
                        UserInterface.WriteAt("|", startCol + formWidth - 1, startRow + line);
                    }
                }

                //Print Titles
                UserInterface.WriteAt("Account Details", startCol + 12, startRow + 1);
                //print Account number:
                string accountNumber = "Account No: " + accountNo;
                UserInterface.WriteAt(accountNumber, startCol + 2, startRow + 4);
                string path = "../../../../" + accountNo + ".txt";
           
                //Get information from account file

                string[] fieldLabels = { "First Name: ", "Last Name: ", "Address: ", "Phone: ", "Email: ", "Account No: ", "Balance: " };
                string[] fieldLines = new string[7];
                string[] transactions = new string[5];
                //Account balance variable
                string accountBalanceFromText = "";
                try
                {
                    //Get Account details and transactions
                    StreamReader sr = new StreamReader(path);
                    string line = sr.ReadLine();
                    //int noOfLines = line.Length;
                    //int linePointer = 5; 
                    int itemNo = 0;
                    while (line != null)
                    {
                        if(itemNo > 6)
                        {
                            break;
                        }
                        if (itemNo <= 6)
                        {
                            if(itemNo == 6)
                            {
                                accountBalanceFromText = line;
                            }

                            fieldLines[itemNo] = fieldLabels[itemNo] + line;

                        }
                        
                        ++itemNo;
                        line = sr.ReadLine();
                    }

                    sr.Close();

                    string[] sentences = File.ReadAllLines(path);


                    int noOfLines = sentences.Length;
                    int lineIncrement = 0;
                    int transcationLoopVar = 0;
                    
                    foreach (string lineText in sentences)
                    {
                        if(noOfLines == 7)
                        {
                            break;
                        }else if (noOfLines >7 && lineIncrement >6 && noOfLines <13)
                        {
                            transactions[transcationLoopVar] = lineText;
                            ++transcationLoopVar;
                        }else if (noOfLines > 7 && lineIncrement > 6 && noOfLines >= 13)
                        {
                            if((noOfLines - lineIncrement) <= 5)
                            {
                                transactions[transcationLoopVar] = lineText;
                                ++transcationLoopVar;
                            }
                        }
                        ++lineIncrement;
                    }

                  
                   
                }
                catch (Exception e) { Console.WriteLine(e); }
                
                //Print Account Balance
                string accountBalance = "Account Balance: " + accountBalanceFromText;
                UserInterface.WriteAt(accountBalance, startCol + 2, startRow + 5);

                //Print info
                for (int field = 0; field < fieldLines.Length - 2; ++field)
                {
                    UserInterface.WriteAt(fieldLines[field], startCol + 2, startRow + 6 + field);
                }

                //Print transactions:
                for (int field = 0; field < transactions.Length; ++field)
                {
                    UserInterface.WriteAt(transactions[field], startCol + 2, startRow + 13 + field);
                }
                
                //Email or not
                UserInterface.WriteAt("Email Statment (y/n)? : ", startCol, startRow + 19);
                String answer = Console.ReadLine();
                if (answer.CompareTo("n") == 0)
                {
                    break;
                }
                else
                {
                    string[] body = new string[13];
                    int lineCounter = 0;
                    foreach(string line in fieldLines)
                    {
                        body[lineCounter] = line;
                        ++lineCounter;
                    }
                    foreach(string line in transactions)
                    {
                        body[lineCounter] = line;
                        ++lineCounter;
                    }
                    sendMail(body);
                    UserInterface.WriteAt("Email has been sent ", startCol, startRow + 20);
                    Console.ReadKey();
                    break;
                    
                }

            } while (true);

          
        }
        //Send email method
        public static void sendMail(string[] mailBody)
        {
            string body = String.Join(" \n", mailBody);

            var smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new NetworkCredential("dotnetassignment01@gmail.com", "assignment01"),
                EnableSsl = true,
            };

            smtpClient.Send("dotnetassignment01@gmail.com", "dotnetassignment01@gmail.com", "Account Statemen", body);
        }

    }
//Delete account class
    class DeleteAccount
    {
        //Create delete Account variables
        string[] deleteAccountFields = {"Account number: " };
        int[] deleteAccountFieldPos = new int[2];
        string[] deleteAccountInputs = new string[1];

        //Create deleteAccount form
        public void deleteAccount(int noLines, int formWidth, int startRow, int startCol)
        {
            do
            {
                Console.Clear();
                UserInterface.origRow = Console.CursorTop;
                UserInterface.origCol = Console.CursorLeft;

                String answer = "";
                int deleteAccountCursorX;
                int deleteAccountCursorY;
                bool searchAnother = false;
                bool validAccount = true;

                //Print the border
                for (int line = 0; line < noLines; line++)
                {
                    if (line == 0 | line == 2 | line == (noLines - 1))
                    {
                        for (int col = 0; col < formWidth; col++)
                        {
                            UserInterface.WriteAt("=", startCol + col, startRow + line);
                        }
                    }
                    else
                    {
                        UserInterface.WriteAt("|", startCol, startRow + line);
                        UserInterface.WriteAt("|", startCol + formWidth - 1, startRow + line);
                    }
                }

                //Print Titles
                UserInterface.WriteAt("Delete Account", startCol + 18, startRow + 1);
                UserInterface.WriteAt("Enter details", startCol + 18, startRow + 3);

                //Field Names display
                int item = 0;
                foreach (string fieldName in deleteAccountFields)
                {
                    UserInterface.WriteAt(fieldName, startCol + 6, startRow + 5 + item);
                    deleteAccountFieldPos[1] = Console.CursorTop;
                    deleteAccountFieldPos[0] = Console.CursorLeft;
                    ++item;
                }

                //Get user account number
                for (int field = 0; field < item; field++)
                {
                    Console.SetCursorPosition(deleteAccountFieldPos[0], deleteAccountFieldPos[1]);
                    string temp = Console.ReadLine();

                    //check if input is Integer and within 10 characters length
                    while (temp.Length > 10 || temp.Length < 1 || !(int.TryParse(temp, out int value)))
                    {
                        validAccount = false;
                        UserInterface.WriteAt("Invalid account number", startCol + 6, startRow + 8);
                        UserInterface.WriteAt("Check another account (y/n)?", startCol + 6, startRow + 9);

                        answer = Console.ReadLine();

                        if (answer.CompareTo("y") == 0)
                        {
                            UserInterface.WriteAt("                  ", deleteAccountFieldPos[0], deleteAccountFieldPos[1]);
                            UserInterface.WriteAt("                       ", startCol + 6, startRow + 8);
                            UserInterface.WriteAt("                             ", startCol + 6, startRow + 9);
                            Console.SetCursorPosition(deleteAccountFieldPos[0], deleteAccountFieldPos[1]);
                            temp = Console.ReadLine();
                            validAccount = true;
                        }
                        else
                        {
                            searchAnother = false;
                            break;
                        };

                    }
                    if (validAccount)
                    {
                        deleteAccountInputs[field] = temp;
                        UserInterface.WriteAt("                                   ", startCol + 6, startRow + 8);
                    }

                }

                try
                {

                    string searchAnotherAccount = "";
                    if (!validAccount)
                    {
                        break;
                    }
                    string path = "../../../../" + deleteAccountInputs[0] + ".txt";

                    //bool continueAnotherAccount = false;
                    if (File.Exists(path))
                    {
                        UserInterface.WriteAt("Account found", startCol + 13, startRow + 8);
                        accoutDetails(14, 40, 9, 5, deleteAccountInputs[0]);

                    }
                    else
                    {
                        UserInterface.WriteAt("Account not found", startCol + 6, startRow + 8);
                        UserInterface.WriteAt("Check another account (y/n)?", startCol + 6, startRow + 9);
                        deleteAccountCursorX = Console.CursorTop;
                        deleteAccountCursorY = Console.CursorLeft;

                        searchAnotherAccount = Console.ReadLine();
                    }

                    if (searchAnotherAccount.CompareTo("y") == 0)
                    {
                        UserInterface.WriteAt("                       ", startCol + 6, startRow + 8);
                        UserInterface.WriteAt("                             ", startCol + 6, startRow + 9);
                    }
                    else { break; };

                }
                catch (Exception e)
                {

                }

            } while (true);
        }
//Print account details method
        public void accoutDetails(int noLines, int formWidth, int startRow, int startCol, string accountNo)
        {
            do
            {
                //Print border
                for (int line = 0; line < noLines; line++)
                {
                    if (line == 0 | line == 2 | line == (noLines - 1))
                    {
                        for (int col = 0; col < formWidth; col++)
                        {
                            UserInterface.WriteAt("=", startCol + col, startRow + line);
                        }
                    }
                    else
                    {
                        UserInterface.WriteAt("|", startCol, startRow + line);
                        UserInterface.WriteAt("|", startCol + formWidth - 1, startRow + line);
                    }
                }

                //Print Titles
                UserInterface.WriteAt("Account Details", startCol + 12, startRow + 1);
                //print Account number:
                string accountNumber = "Account No: " + accountNo;
                UserInterface.WriteAt(accountNumber, startCol + 2, startRow + 4);
                string path = "../../../../" + accountNo + ".txt";
                string sentence;
                //Get information from account file

                string[] fieldLabels = { "First Name: ", "Last Name: ", "Address: ", "Phone: ", "Email: ", "Account No: ", "Balance: " };
                string[] fieldLines = new string[7];

                //Account balance variable
                string accountBalanceFromText = "";
                try
                {
                    using (StreamReader sr = new StreamReader(path))
                    {
                        string line = sr.ReadLine();
                        int itemNo = 0;
                        while (line != null)
                        {
                            if (itemNo == 6)
                            {
                                accountBalanceFromText = line;
                                break;
                            }
                            fieldLines[itemNo] = fieldLabels[itemNo] + line;
                            ++itemNo;
                            line = sr.ReadLine();
                        }

                    }
                    

                }
                catch (Exception e) { Console.WriteLine(e); }

                //Print Account Balance
                string accountBalance = "Account Balance: " + accountBalanceFromText;
                UserInterface.WriteAt(accountBalance, startCol + 2, startRow + 5);

                //Print info
                for (int field = 0; field < fieldLines.Length - 2; ++field)
                {
                    UserInterface.WriteAt(fieldLines[field], startCol + 2, startRow + 6 + field);
                }

                //Delete account
                bool delete = false;
                try
                {
                    UserInterface.WriteAt("Delete Account? (y/n)?:  ", startCol, startRow + 14);
                    string answer = Console.ReadLine();
                    if (answer.CompareTo("n") == 0)
                    {
                        break;
                    }
                    else
                    {
                        string deleteAccountPath = "../../../../" + accountNo + ".txt";
                        GC.Collect();
                        GC.WaitForPendingFinalizers();
                        delete = true;
                        File.Delete(deleteAccountPath);
                        GC.Collect();
                        GC.WaitForPendingFinalizers();
                        Console.WriteLine("Account Deleted");
                        //Console.ReadLine();
                        break;
                    }
                }
                catch (Exception e) 
                {
                    Console.WriteLine(e);
                }
 
                


            } while (true);

     
        }
    }



    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                bool continueScreen = true;
                LoginInterface loginI = new LoginInterface();
                loginI.loginScreen(10, 50, 0, 5);

                while (continueScreen)
                {
                    MainMenuInterface mainMenuI = new MainMenuInterface();
                    int choice = mainMenuI.menuScreen(13, 50, 0, 5);

                    if (choice == 1)
                    {
                        CreateAccountInterface createAccount = new CreateAccountInterface();
                        createAccount.createAccount(15, 50, 0, 5);
                    }
                    else if (choice == 2)
                    {
                        searchAccountInterface searchAccountI = new searchAccountInterface();
                        searchAccountI.searchAccount(7, 50, 0, 5);
                    }
                    else if (choice == 3)
                    {
                        DepositInterface deposit = new DepositInterface();
                        deposit.deposit(10, 50, 0, 5);
                    }
                    else if (choice == 4)
                    {
                        WithdrawInterface withdraw = new WithdrawInterface();
                        withdraw.withdraw(8, 50, 0, 5);

                    }
                    else if (choice == 5)
                    {

                        AccountStatement accountStatement = new AccountStatement();
                        accountStatement.accountStatement(7, 50, 0, 5);
                    }
                    else if (choice == 6)
                    {
                        DeleteAccount deleteAccount = new DeleteAccount();
                        deleteAccount.deleteAccount(7, 50, 0, 5);
                    }
                    else if (choice == 7)
                    {
                        continueScreen = false;
                       
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Wrong Choice.");

                    }

                }

            }catch(Exception e)
            {
                Console.WriteLine(e);
            }
            
        }
    }
}
